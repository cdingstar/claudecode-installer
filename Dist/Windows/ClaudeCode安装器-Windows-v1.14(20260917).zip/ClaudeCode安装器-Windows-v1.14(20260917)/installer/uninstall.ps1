﻿# ============================================================
# Claude Code 卸载工具 ——「卸载ClaudeCode.bat」调起
# 语义：卸载本安装器安装的全部用户级组件（Claude Code / Node.js /
#       Git / Python / VS Code）+ User 级 PATH / npm 配置清理
# 安全边界：只动本安装器的固定安装位置，系统里其他方式安装的软件不受影响
# 个人数据（~/.claude 配置、聊天记录、API Key、VS Code 用户数据）
#       默认保留，确认后输入 D 才删除
# 异常处理：
#   · 中断：随时 Ctrl+C / 关窗口；每步操作前先写日志，中断后重新双击
#          本工具可续跑（幂等）；中断也会生成标注「被中断」的卸载报告
#   · 重试：单个组件删除失败自动重试 3 次（重试前重杀相关进程）；
#          权限类错误不重试，直接给出处理办法
#   · 权限：UnauthorizedAccessException → 提示右键「以管理员身份运行」
#   · 兜底：全局 try/catch/finally（Ctrl+C 也会进 finally），
#          任何异常/中断都写日志 + 报告；日志目录不可写时退回 %TEMP%
# ============================================================

$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }

$Script:UninstallerVersion = '1.1'
$Script:AppRoot = Split-Path -Parent $PSScriptRoot
$installerDir = Join-Path $Script:AppRoot 'installer'

# ---- 日志初始化（安装器目录不可写时退回 %TEMP%，保证任何环境都有日志）----
function Initialize-UninstallLog {
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $header = [char]0xFEFF + ("==== Claude Code 卸载日志 开始 {0} ====`r`n" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
    $preferred = Join-Path $Script:AppRoot 'logs'
    try {
        New-Item -ItemType Directory -Path $preferred -Force | Out-Null
        $f = Join-Path $preferred ("uninstall-{0}.log" -f $stamp)
        [System.IO.File]::WriteAllText($f, $header)
        return $f
    } catch { }
    try {
        $f = Join-Path ([System.IO.Path]::GetTempPath()) ("claude-uninstall-{0}.log" -f $stamp)
        [System.IO.File]::WriteAllText($f, $header)
        Write-Host ("  [注意] 安装器目录无写权限，日志改存：{0}" -f $f) -ForegroundColor Yellow
        return $f
    } catch { return $null }
}
$Script:LogFile = Initialize-UninstallLog

function Write-Log {
    param([string]$Message, [string]$Level = 'INFO')
    if ($Script:LogFile) {
        $line = "[{0}] [{1}] {2}" -f (Get-Date -Format 'HH:mm:ss'), $Level, $Message
        [System.IO.File]::AppendAllText($Script:LogFile, $line + "`r`n", (New-Object System.Text.UTF8Encoding($false)))
    }
}
function Write-Banner {
    param([string]$Text)
    $line = '=' * 56
    Write-Host ''
    Write-Host $line -ForegroundColor Cyan
    Write-Host ("  {0}" -f $Text) -ForegroundColor Cyan
    Write-Host $line -ForegroundColor Cyan
    Write-Log -Message $Text -Level 'BANNER'
}
function Write-StepHeader {
    param([int]$Index, [int]$Total, [string]$Name)
    Write-Host ''
    Write-Host ("[{0}/{1}] {2}" -f $Index, $Total, $Name) -ForegroundColor White
    Write-Log -Message ("步骤 {0}/{1}：{2}" -f $Index, $Total, $Name) -Level 'STEP'
}
function Write-Info {
    param([string]$Message)
    Write-Host ("  {0}" -f $Message) -ForegroundColor Gray
    Write-Log -Message $Message -Level 'INFO'
}
function Write-Ok {
    param([string]$Message)
    Write-Host ("  [OK] {0}" -f $Message) -ForegroundColor Green
    Write-Log -Message $Message -Level 'OK'
}
function Write-WarnMsg {
    param([string]$Message)
    Write-Host ("  [注意] {0}" -f $Message) -ForegroundColor Yellow
    Write-Log -Message $Message -Level 'WARN'
}
function Write-Fail {
    param([string]$Message)
    Write-Host ("  [失败] {0}" -f $Message) -ForegroundColor Red
    Write-Log -Message $Message -Level 'FAIL'
}

# 复用 env-utils（Remove-UserPath / Update-SessionPath；其内部依赖 Write-Log，上面已就位）
. (Join-Path $installerDir 'common\env-utils.ps1')

# ---- 目标位置（与安装器各 step 写入的位置一一对应）----
$NodeDir    = Join-Path $env:LOCALAPPDATA 'Programs\nodejs'
$GitDir     = Join-Path $env:LOCALAPPDATA 'Programs\Git'
$PyDir      = Join-Path $env:LOCALAPPDATA 'Programs\Python\Python312'
$NpmGlobal  = Join-Path $env:APPDATA 'npm'
$NpmCache   = Join-Path $env:LOCALAPPDATA 'npm-cache'
$VscodeDir  = Join-Path $env:LOCALAPPDATA 'Programs\Microsoft VS Code'
$ClaudeCfg  = Join-Path $env:USERPROFILE '.claude'
$ClaudeJson = Join-Path $env:USERPROFILE '.claude.json'
$VscodeData = Join-Path $env:APPDATA 'Code'
$NpmrcFile  = Join-Path $env:USERPROFILE '.npmrc'

# ---- 运行状态（供日志 / 报告 / 中断兜底使用）----
$Script:Results = @()
$Script:FailedCount = 0
$Script:RunStatus = '未开始'      # 未开始 → 进行中 → 完成 / 已取消 / 异常 / 被中断
$Script:ElapsedSec = 0

function Add-Result {
    param([string]$Name, [string]$Status)
    $Script:Results += @{ Name = $Name; Status = $Status }
    if ($Status -like '失败*') { $Script:FailedCount++ }
    Write-Log -Message ("结果：{0} → {1}" -f $Name, $Status) -Level 'RESULT'
}

function Get-IsAdmin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    return (New-Object Security.Principal.WindowsPrincipal($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# 探测 Claude Code 是否装过（shim 或包目录任一存在即算）
function Test-ClaudeInstalled {
    if (Test-Path -LiteralPath (Join-Path $NpmGlobal 'claude.cmd')) { return $true }
    if (Test-Path -LiteralPath (Join-Path $NpmGlobal 'node_modules\@anthropic-ai\claude-code')) { return $true }
    return $false
}

# 强制结束相关进程（已提前提示用户保存并关闭；node 只杀装在本安装器目录里的）
# 每次删除重试前也会调用：占用进程可能被系统重新拉起
function Stop-RelatedProcesses {
    Write-Info '正在结束相关进程（claude / VS Code / 本安装器的 node）……'
    $killed = 0
    try {
        foreach ($name in @('claude', 'Code')) {
            $procs = @(Get-Process -Name $name -ErrorAction SilentlyContinue)
            if ($procs.Count -gt 0) {
                $procs | Stop-Process -Force -ErrorAction SilentlyContinue
                $killed += $procs.Count
                Write-Log -Message ("已结束进程：{0} × {1}" -f $name, $procs.Count) -Level 'INFO'
            }
        }
        $escaped = [regex]::Escape($NodeDir)
        $nodeProcs = @(Get-Process -Name node -ErrorAction SilentlyContinue |
            Where-Object { $_.Path -and ($_.Path -match ('^' + $escaped)) })
        if ($nodeProcs.Count -gt 0) {
            $nodeProcs | Stop-Process -Force -ErrorAction SilentlyContinue
            $killed += $nodeProcs.Count
            Write-Log -Message ("已结束进程：node（本安装器目录）× {0}" -f $nodeProcs.Count) -Level 'INFO'
        }
    } catch {
        Write-Log -Message ("进程清理异常（忽略）：{0}" -f $_.Exception.Message) -Level 'WARN'
    }
    if ($killed -eq 0) { Write-Info '没有发现占用中的相关进程' }
}

# 删除目录/文件（带重试：最多 3 次，指数退避，重试前重杀进程；
# 权限类错误不重试，直接给出针对性处理办法）
function Remove-TreeSafely {
    param([string]$Path, [string]$Name, [int]$MaxAttempts = 3)
    if (-not (Test-Path -LiteralPath $Path)) { return $true }
    Write-Log -Message ("开始删除：{0}" -f $Path) -Level 'INFO'
    for ($attempt = 1; $attempt -le $MaxAttempts; $attempt++) {
        try {
            Remove-Item -LiteralPath $Path -Recurse -Force -ErrorAction Stop
            if (-not (Test-Path -LiteralPath $Path)) {
                Write-Ok ("已删除：{0}" -f $Path)
                return $true
            }
            throw '删除命令已返回但路径仍存在（可能被杀毒软件占用或拦截）'
        } catch {
            $exType = $_.Exception.GetType().Name
            $exMsg = $_.Exception.Message
            Write-Log -Message ("删除失败（第 {0}/{1} 次，异常 {2}）：{3} —— {4}" -f $attempt, $MaxAttempts, $exType, $Path, $exMsg) -Level 'WARN'
            if ($exType -eq 'UnauthorizedAccessException') {
                # 权限不足：重试没有意义，直接给出处理办法
                Write-Fail ("{0} 权限不足，无法删除：{1}" -f $Name, $Path)
                if (-not (Get-IsAdmin)) {
                    Write-WarnMsg '处理办法：右键「卸载ClaudeCode.bat」→「以管理员身份运行」，再跑一次'
                } else {
                    Write-WarnMsg '处理办法：已是管理员仍被拒，多为杀毒软件拦截——把该目录加入白名单后重跑'
                }
                return $false
            }
            if ($attempt -lt $MaxAttempts) {
                Write-Info ("  文件可能被占用，{0} 秒后自动重试（还可重试 {1} 次）……" -f ($attempt * 2), ($MaxAttempts - $attempt))
                Start-Sleep -Seconds ($attempt * 2)
                Stop-RelatedProcesses   # 占用进程可能被重新拉起，删前再杀一遍
            }
        }
    }
    Write-Fail ("{0} 自动重试 {1} 次后仍删除失败：{2}" -f $Name, $MaxAttempts, $Path)
    Write-WarnMsg '处理办法：关闭所有相关程序（或重启电脑）后重新双击「卸载ClaudeCode.bat」；也可手动删除该文件夹'
    return $false
}

# 清理 ~/.npmrc 里本安装器写入的行（镜像源 / prefix / cache），保留用户自己的配置
# 写入走「临时文件 + 替换」，中断也不会把 ~/.npmrc 写坏；开头顺带清理上次中断残留的临时文件
function Remove-InstallerNpmrcLines {
    $tmpFile = "$NpmrcFile.uninstall-tmp"
    if (Test-Path -LiteralPath $tmpFile) {
        Remove-Item -LiteralPath $tmpFile -Force -ErrorAction SilentlyContinue
        Write-Log -Message ('已清理上次中断残留的临时文件：{0}' -f $tmpFile) -Level 'INFO'
    }
    if (-not (Test-Path -LiteralPath $NpmrcFile)) { return }
    try {
        $lines = [System.IO.File]::ReadAllLines($NpmrcFile)
        $keep = @($lines | Where-Object {
            $_ -notmatch '^registry=https://(registry\.npmmirror\.com|mirrors\.cloud\.tencent\.com/npm/)' -and
            $_ -notmatch ('^prefix=' + [regex]::Escape($NpmGlobal) + '\s*$') -and
            $_ -notmatch ('^cache=' + [regex]::Escape($NpmCache) + '\s*$')
        })
        if ($keep.Count -eq $lines.Count) { Write-Info 'npm 配置（~/.npmrc）无需清理'; return }
        if (@($keep | Where-Object { $_ -and $_.Trim() }).Count -eq 0) {
            Remove-Item -LiteralPath $NpmrcFile -Force
            Write-Ok 'npm 配置（~/.npmrc）只剩安装器内容，已删除整个文件'
        } else {
            [System.IO.File]::WriteAllLines($tmpFile, $keep)
            Move-Item -LiteralPath $tmpFile -Destination $NpmrcFile -Force
            Write-Ok 'npm 配置（~/.npmrc）已移除安装器写入的行'
        }
    } catch {
        Remove-Item -LiteralPath $tmpFile -Force -ErrorAction SilentlyContinue
        Write-WarnMsg ("npm 配置清理失败（可手动编辑 ~/.npmrc 删除安装器写入的行）：{0}" -f $_.Exception.Message)
    }
}

# 生成卸载报告（正常完成 / 被中断 / 异常都会调用，报告里标注运行状态）
function Write-UninstallReport {
    $report = Join-Path $Script:AppRoot '卸载报告.txt'
    $lines = @(
        '==============================================',
        ("        Claude Code 卸载报告（Windows 版 v{0}）" -f $Script:UninstallerVersion),
        ("生成时间：{0}（耗时 {1} 秒）" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Script:ElapsedSec),
        '==============================================',
        '',
        ("【运行状态】{0}" -f $Script:RunStatus)
    )
    if ($Script:RunStatus -eq '被中断' -or $Script:RunStatus -eq '异常') {
        $lines += '  本次未完成：重新双击「卸载ClaudeCode.bat」会继续剩余部分（已完成的不会重来）'
        $lines += '  中断位置见日志中的最后一条「开始删除/步骤」记录'
    }
    $lines += ''
    $lines += '【卸载明细】'
    if ($Script:Results.Count -eq 0) { $lines += '  （尚未执行到删除步骤）' }
    foreach ($r in $Script:Results) { $lines += ("  {0}: {1}" -f $r.Name, $r.Status) }
    $lines += ''
    $lines += '【日志】'
    $lines += ("  {0}" -f $Script:LogFile)
    $lines += ''
    $lines += '【安全边界】只卸载了本安装器安装的用户级副本；'
    $lines += '          系统里其他方式安装的 Node / Git / Python / VS Code 不受影响。'
    $lines += ''
    $lines += '【重新安装】随时重新双击「双击安装ClaudeCode.bat」即可重装。'
    $lines += '【遇到问题】把「卸载报告.txt」和 logs 文件夹发给开发者：'
    $lines += '          邮箱 cdingstar@outlook.com / 微信 cdingstar'
    try {
        [System.IO.File]::WriteAllText($report, ($lines -join "`r`n") + "`r`n", (New-Object System.Text.UTF8Encoding($true)))
        Write-Ok ("卸载报告：{0}" -f $report)
    } catch {
        Write-WarnMsg ("卸载报告写入失败（目录无写权限？）：{0}" -f $_.Exception.Message)
    }
}

# ---- 主流程（早退路径用 return；全局兜底在后面的 try/catch/finally）----
function Invoke-UninstallMain {
    Write-Banner ("Claude Code 卸载工具 v{0}（只卸载本安装器安装的内容）" -f $Script:UninstallerVersion)
    if ($Script:LogFile) { Write-Info ("日志文件：{0}" -f $Script:LogFile) }
    Write-Info '卸载过程中随时可按 Ctrl+C 中断；中断后重新双击本工具会继续完成剩余部分'

    # ---- 1. 扫描 ----
    Write-StepHeader -Index 1 -Total 3 -Name '检查已安装组件'
    $foundClaude = Test-ClaudeInstalled
    $foundNode   = Test-Path -LiteralPath (Join-Path $NodeDir 'node.exe')
    $foundGit    = Test-Path -LiteralPath (Join-Path $GitDir 'cmd\git.exe')
    $foundPy     = Test-Path -LiteralPath (Join-Path $PyDir 'python.exe')
    $foundVscode = Test-Path -LiteralPath (Join-Path $VscodeDir 'Code.exe')
    $foundData   = (Test-Path -LiteralPath $ClaudeCfg) -or (Test-Path -LiteralPath $ClaudeJson)
    Write-Log -Message ("扫描结果：Claude={0} Node={1} Git={2} Python={3} VSCode={4} 个人数据={5}" -f `
        [int]$foundClaude, [int]$foundNode, [int]$foundGit, [int]$foundPy, [int]$foundVscode, [int]$foundData) -Level 'INFO'

    function Show-Found {
        param([bool]$Found, [string]$Label)
        if ($Found) { Write-Host ("  [发现] {0}" -f $Label) -ForegroundColor Green; Write-Log -Message ("[发现] " + $Label) }
        else { Write-Host ("  [未安装] {0}" -f $Label) -ForegroundColor DarkGray; Write-Log -Message ("[未安装] " + $Label) }
    }
    Show-Found -Found $foundClaude -Label ('Claude Code：{0}' -f $NpmGlobal)
    Show-Found -Found $foundNode   -Label ('Node.js：{0}' -f $NodeDir)
    Show-Found -Found $foundGit    -Label ('Git：{0}' -f $GitDir)
    Show-Found -Found $foundPy     -Label ('Python：{0}' -f $PyDir)
    Show-Found -Found $foundVscode -Label ('VS Code：{0}' -f $VscodeDir)
    if ($foundData) { Write-Host ("  [发现] 个人数据：{0}（默认保留）" -f $ClaudeCfg) -ForegroundColor Green; Write-Log -Message ("[发现] 个人数据：" + $ClaudeCfg) }

    $anyComponent = $foundClaude -or $foundNode -or $foundGit -or $foundPy -or $foundVscode
    if (-not $anyComponent -and -not $foundData) {
        Write-Ok '未发现本安装器安装的组件或数据，无需卸载'
        return 0
    }

    # ---- 2. 确认 ----
    Write-StepHeader -Index 2 -Total 3 -Name '确认卸载'
    if ($anyComponent) {
        Write-WarnMsg '请先保存并关闭：VS Code、正在运行的 claude 会话和其他终端窗口'
        Read-Host '  关闭后按回车继续（想取消请直接关掉本窗口）'
        Write-Log -Message '用户已确认程序关闭，继续' -Level 'INFO'

        function Write-PlanLine {
            param([string]$Message)
            Write-Host ("    {0}" -f $Message) -ForegroundColor Yellow
            Write-Log -Message ("[将删除] " + $Message) -Level 'INFO'
        }
        Write-Host ''
        Write-Host '  即将删除以下内容（个人数据除外）：' -ForegroundColor Yellow
        if ($foundClaude) { Write-PlanLine ("Claude Code：{0}（含 claude 命令）" -f $NpmGlobal) }
        if ($foundClaude) { Write-PlanLine ("npm 下载缓存：{0}" -f $NpmCache) }
        if ($foundNode)   { Write-PlanLine ("Node.js：{0}" -f $NodeDir) }
        if ($foundGit)    { Write-PlanLine ("Git：{0}" -f $GitDir) }
        if ($foundPy)     { Write-PlanLine ("Python：{0}" -f $PyDir) }
        if ($foundVscode) { Write-PlanLine ("VS Code：{0}" -f $VscodeDir) }
        Write-PlanLine '以及「用户环境变量 Path」里对应的条目、~/.npmrc 里安装器写入的行'
        Write-Info '执行过程中随时可按 Ctrl+C 中断；已删除的部分不会恢复，中断后重跑本工具会继续'
        $confirm = Read-Host '  确认卸载请输入 Y（回车或其他任意键取消）'
        if ($confirm -notmatch '^[Yy]') {
            $Script:RunStatus = '已取消'
            Write-Info '已取消，未做任何改动'
            return 0
        }
        Write-Log -Message '用户输入 Y，确认卸载' -Level 'INFO'
    }

    $wipeData = ''
    if ($foundData) {
        Write-Host ''
        Write-Host '  个人数据包括：' -ForegroundColor Gray
        Write-Host ("    {0}（配置、聊天记录、全局指令、API Key）" -f $ClaudeCfg) -ForegroundColor Gray
        Write-Host ("    {0}" -f $ClaudeJson) -ForegroundColor Gray
        Write-Host ("    {0}（VS Code 设置与已装扩展）" -f $VscodeData) -ForegroundColor Gray
        $wipeData = Read-Host '  要彻底清空请输入 D，回车保留（推荐：重装后免重新配置）'
        Write-Log -Message ("个人数据处理选择：{0}" -f $(if ($wipeData -match '^[Dd]') { 'D（删除）' } else { '保留' })) -Level 'INFO'
    }

    # ---- 3. 执行 ----
    Write-StepHeader -Index 3 -Total 3 -Name '执行卸载'
    $Script:RunStatus = '进行中'
    $sw = [Diagnostics.Stopwatch]::StartNew()
    Stop-RelatedProcesses

    # VS Code 扩展：先于 VS Code 本体卸载（尽力而为，失败不影响）
    if ($foundVscode) {
        $codeCmd = Join-Path $VscodeDir 'bin\code.cmd'
        if (Test-Path -LiteralPath $codeCmd) {
            Write-Info '正在卸载 VS Code 的 Claude Code 扩展（尽力而为）……'
            try {
                $prevEap = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
                & $codeCmd --uninstall-extension anthropic.claude-code 2>&1 | Out-Null
                $ErrorActionPreference = $prevEap
                Write-Log -Message 'VS Code 扩展卸载命令已执行' -Level 'INFO'
            } catch {
                Write-Log -Message ("VS Code 扩展卸载命令异常（忽略）：{0}" -f $_.Exception.Message) -Level 'WARN'
            }
        }
    }

    # Claude Code：优先 npm 正规卸载（需本安装器的 npm），再手动兜底删残留
    if ($foundClaude) {
        $npmCmd = Join-Path $NodeDir 'npm.cmd'
        if (Test-Path -LiteralPath $npmCmd) {
            Write-Info '正在通过 npm 卸载 Claude Code……'
            try {
                $prevEap = $ErrorActionPreference; $ErrorActionPreference = 'Continue'
                & $npmCmd uninstall -g '@anthropic-ai/claude-code' 2>&1 | Out-Null
                $ErrorActionPreference = $prevEap
                Write-Log -Message 'npm uninstall 命令已执行' -Level 'INFO'
            } catch {
                Write-Log -Message ("npm uninstall 异常（改用直接删除）：{0}" -f $_.Exception.Message) -Level 'WARN'
            }
        }
        $ok = $true
        foreach ($sub in @('node_modules\@anthropic-ai\claude-code', 'node_modules\@anthropic-ai\claude-code-win32-x64')) {
            $p = Join-Path $NpmGlobal $sub
            $ok = (Remove-TreeSafely -Path $p -Name 'Claude Code') -and $ok
        }
        foreach ($shim in @('claude.cmd', 'claude', 'claude.ps1')) {
            $ok = (Remove-TreeSafely -Path (Join-Path $NpmGlobal $shim) -Name 'claude 命令') -and $ok
        }
        if (Test-Path -LiteralPath $NpmCache) { $ok = (Remove-TreeSafely -Path $NpmCache -Name 'npm 缓存') -and $ok }
        Add-Result -Name 'Claude Code' -Status ($(if ($ok) { '成功' } else { '失败（见日志）' }))
    }

    # Node / Git / Python / VS Code：按依赖顺序删目录（Node 已在上面用完）
    if ($foundNode) {
        Add-Result -Name 'Node.js' -Status ($(if (Remove-TreeSafely -Path $NodeDir -Name 'Node.js') { '成功' } else { '失败（见日志）' }))
    }
    if ($foundGit) {
        Add-Result -Name 'Git' -Status ($(if (Remove-TreeSafely -Path $GitDir -Name 'Git') { '成功' } else { '失败（见日志）' }))
    }
    if ($foundPy) {
        Add-Result -Name 'Python' -Status ($(if (Remove-TreeSafely -Path $PyDir -Name 'Python') { '成功' } else { '失败（见日志）' }))
    }
    if ($foundVscode) {
        $vsOk = $true
        # 优先官方卸载器（顺带清注册表），失败再直接删目录
        $unins = Join-Path $VscodeDir 'unins000.exe'
        if (Test-Path -LiteralPath $unins) {
            Write-Info '正在运行 VS Code 官方卸载程序（静默，最多等 3 分钟）……'
            try {
                $p = Start-Process -FilePath $unins -ArgumentList @('/VERYSILENT', '/NORESTART') -WindowStyle Hidden -PassThru
                if (-not $p.WaitForExit(180000)) {
                    Write-WarnMsg 'VS Code 官方卸载程序超时（3 分钟），强制结束并改为直接删除目录'
                    try { $p.Kill() } catch { }
                } else {
                    Write-Log -Message 'VS Code 官方卸载程序已退出' -Level 'INFO'
                }
            } catch {
                Write-Log -Message ("官方卸载器运行异常（改为直接删目录）：{0}" -f $_.Exception.Message) -Level 'WARN'
            }
            # Inno 卸载器可能异步删除，等最多 15 秒目录消失，避免与手动删除抢文件
            for ($i = 0; $i -lt 15 -and (Test-Path -LiteralPath $VscodeDir); $i++) { Start-Sleep -Seconds 1 }
        }
        if (Test-Path -LiteralPath $VscodeDir) { $vsOk = Remove-TreeSafely -Path $VscodeDir -Name 'VS Code' }
        Add-Result -Name 'VS Code' -Status ($(if ($vsOk) { '成功' } else { '失败（见日志）' }))
    }

    # PATH 与 npm 配置清理（无条件执行：Remove-UserPath 对不存在的条目是空操作）
    Remove-UserPath -Dirs @(
        $NpmGlobal, $NodeDir,
        (Join-Path $GitDir 'cmd'), (Join-Path $GitDir 'bin'),
        $PyDir, (Join-Path $PyDir 'Scripts'),
        (Join-Path $VscodeDir 'bin')
    )
    Remove-InstallerNpmrcLines
    Update-SessionPath
    Write-Ok '用户环境变量 Path 与 npm 配置已清理'

    # 个人数据（仅在用户输入 D 时删除）
    if ($foundData) {
        if ($wipeData -match '^[Dd]') {
            $dOk = $true
            if (Test-Path -LiteralPath $ClaudeCfg) { $dOk = (Remove-TreeSafely -Path $ClaudeCfg -Name 'Claude 配置') -and $dOk }
            $dOk = (Remove-TreeSafely -Path $ClaudeJson -Name '.claude.json') -and $dOk
            if (Test-Path -LiteralPath $VscodeData) { $dOk = (Remove-TreeSafely -Path $VscodeData -Name 'VS Code 用户数据') -and $dOk }
            Add-Result -Name '个人数据' -Status ($(if ($dOk) { '成功（已彻底删除）' } else { '失败（见日志）' }))
        } else {
            Add-Result -Name '个人数据' -Status '已保留（含配置 / 聊天记录 / API Key）'
        }
    }

    $sw.Stop()
    $Script:ElapsedSec = [int]$sw.Elapsed.TotalSeconds
    $Script:RunStatus = '完成'
    Write-Log -Message ("执行阶段完成，耗时 {0} 秒" -f $Script:ElapsedSec) -Level 'DONE'
    return $(if ($Script:FailedCount -eq 0) { 0 } else { 1 })
}

# ---- 全局兜底：任何异常 / Ctrl+C（finally 必然执行）都写日志与报告 ----
$exitCode = 0
try {
    $exitCode = Invoke-UninstallMain
} catch {
    Write-Fail ("发生未预期错误，卸载中断：{0}" -f $_.Exception.Message)
    if ($_.Exception.GetType().Name -eq 'UnauthorizedAccessException') {
        Write-WarnMsg '疑似权限不足：右键「卸载ClaudeCode.bat」→「以管理员身份运行」后重试'
    } else {
        Write-WarnMsg '请关闭相关程序后重新双击「卸载ClaudeCode.bat」重试（已完成的步骤不用重来）'
    }
    Write-Log -Message ("全局异常：{0}" -f $_.Exception.ToString()) -Level 'FATAL'
    $Script:RunStatus = '异常'
    $exitCode = 2
} finally {
    # Ctrl+C 也会进入这里：状态仍为「进行中」即视为被中断
    if ($Script:RunStatus -eq '进行中') { $Script:RunStatus = '被中断' }
    if ($Script:RunStatus -ne '未开始' -and $Script:RunStatus -ne '已取消') {
        try { Write-UninstallReport } catch { }
    }
    if ($Script:LogFile) {
        Write-Log -Message ("==== Claude Code 卸载日志 结束（运行状态：{0}，退出码 {1}）====" -f $Script:RunStatus, $exitCode) -Level 'DONE'
    }
}
exit $exitCode
